<?php

include "connection.php";

$title = htmlspecialchars($_POST["title"]);
$content = htmlspecialchars($_POST["content"]);

try
{
    session_start();
    $currentUserId = $_SESSION["currentUserId"];

    $insert = $con->prepare("INSERT INTO thread (title, content, userId) VALUES (?,?,?)");
    $insert->bind_param("ssi",$title,$content,$currentUserId);
    $insert->execute();
    

    mysqli_close($con);
    //reopens the home to refresh it
    header("Location: home.php");
    
}
catch(Exception $ex)
{
    header("Location: error.html");
    exit; // Stop executing the remaining PHP
}

?>